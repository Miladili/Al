# Changelog

## 2.1.0
- Reworked Single Layouts to use a normal Elementor Library design document linked to a separate Project Layout manager record.
- Removed the custom Elementor Document Type architecture that could interfere with Elementor editor loading.
- Simplified widget categories and registration to Elementor's standard addon lifecycle.
- Removed global Elementor editor asset enqueueing; Project widget CSS is loaded through widget dependencies.
- Scoped plugin admin CSS to PSS screens only.
- Preserved all existing Project widgets and data functionality.
