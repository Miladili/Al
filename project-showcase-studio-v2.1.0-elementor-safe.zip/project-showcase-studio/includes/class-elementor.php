<?php
namespace PSS;

defined( 'ABSPATH' ) || exit;

/**
 * Elementor integration.
 *
 * Important rule: this class must never change Elementor's global editor,
 * settings, theme locations, or admin UI outside Project Showcase itself.
 */
class Elementor {
	private static $booted = false;
	private static $widget_errors = array();
	private static $dynamic_tag_errors = array();
	private static $widgets_registered = false;
	private static $dynamic_tags_registered = false;

	public static function init() {
		// Follow Elementor's supported addon lifecycle: wait for Elementor itself,
		// then attach to the widget/category/dynamic-tag registration hooks.
		add_action( 'elementor/init', array( __CLASS__, 'boot' ), 5 );
		add_action( 'admin_notices', array( __CLASS__, 'minimum_version_notice' ) );
		self::register_assets();
	}

	public static function boot() {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_category' ), 10 );
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register_widgets' ), 10 );
		add_action( 'elementor/dynamic_tags/register', array( __CLASS__, 'register_dynamic_tags' ), 10 );
		add_filter( 'elementor/document/urls/wp_preview', array( __CLASS__, 'preview_url' ), 10, 2 );
	}

	public static function allow_layout_post_type( $supported, $post_type ) {
		// Kept for BC only. This plugin no longer uses a custom Elementor document type.
		return $supported;
	}

	public static function register_assets() {
		wp_register_style( 'pss-elementor', PSS_URL . 'assets/css/elementor.css', array(), PSS_VERSION );
	}

	/** @deprecated Compatibility shim. Elementor boot is now handled by ::boot(). */
	public static function bootstrap() { self::boot(); }

	public static function enqueue_editor_assets() {
		// Intentionally empty. Widget assets are loaded by Elementor through get_style_depends().
	}

	public static function register_legacy_widgets( $widgets_manager ) {
		self::register_widgets( $widgets_manager );
	}

	public static function register_dynamic_tags_legacy( $dynamic_tags_manager ) {
		self::register_dynamic_tags( $dynamic_tags_manager );
	}

	public static function minimum_version_notice() {
		if ( ! current_user_can( 'manage_options' ) || ! defined( 'ELEMENTOR_VERSION' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || false === strpos( (string) $screen->id, 'elementor' ) ) {
			return;
		}
		if ( version_compare( ELEMENTOR_VERSION, '3.19.0', '<' ) ) {
			echo '<div class="notice notice-warning"><p><strong>Project Showcase Studio:</strong> Elementor 3.19 or newer is required for Project Showcase widgets.</p></div>';
		}
	}

	public static function register_category( $elements_manager ) {
		if ( ! is_object( $elements_manager ) || ! method_exists( $elements_manager, 'add_category' ) ) {
			return;
		}
		$elements_manager->add_category( 'pss-projects', array( 'title' => 'Project Showcase', 'icon' => 'eicon-portfolio' ) );
	}

	public static function register_widgets( $widgets_manager ) {
		if ( self::$widgets_registered || ! is_object( $widgets_manager ) || ! class_exists( '\\Elementor\\Widget_Base' ) ) {
			return;
		}

		// Defensive category registration: Elementor uses one effective category per widget.
		// Ensure our category exists before widget instances ask for get_categories().
		if ( class_exists( '\\Elementor\\Plugin' ) && isset( \Elementor\Plugin::$instance->elements_manager ) ) {
			$elements_manager = \Elementor\Plugin::$instance->elements_manager;
			if ( method_exists( $elements_manager, 'get_categories' ) && ! isset( $elements_manager->get_categories()['pss-projects'] ) && method_exists( $elements_manager, 'add_category' ) ) {
				$elements_manager->add_category( 'pss-projects', array( 'title' => 'Project Showcase', 'icon' => 'eicon-portfolio' ) );
			}
		}

		$register_method = method_exists( $widgets_manager, 'register' )
			? 'register'
			: ( method_exists( $widgets_manager, 'register_widget_type' ) ? 'register_widget_type' : '' );
		if ( '' === $register_method ) {
			return;
		}

		require_once PSS_PATH . 'elementor/widgets/class-base.php';

		$files = array(
			'project-title' => 'Project_Title',
			'project-image' => 'Project_Image',
			'project-meta' => 'Project_Meta',
			'project-description' => 'Project_Description',
			'project-floor-plan' => 'Project_Floor_Plan',
			'project-gallery' => 'Project_Gallery',
			'project-custom-fields' => 'Project_Custom_Fields',
			'project-products' => 'Project_Products',
			'related-projects' => 'Related_Projects',
			'project-navigation' => 'Project_Navigation',
			'project-before-after' => 'Project_Before_After',
			'project-video' => 'Project_Video',
			'project-showcase' => 'Project_Showcase',
			'project-field' => 'Project_Field',
			'project-hero' => 'Project_Hero',
			'project-stats' => 'Project_Stats',
			'project-cta' => 'Project_CTA',
			'project-breadcrumbs' => 'Project_Breadcrumbs',
			'project-share' => 'Project_Share',
			'project-services' => 'Project_Services',
			'project-materials' => 'Project_Materials',
			'project-location' => 'Project_Location',
			'project-inquiry' => 'Project_Inquiry',
			'project-specifications' => 'Project_Specifications',
			'project-tags' => 'Project_Tags',
			'project-features' => 'Project_Features',
		);

		$successful = 0;
		foreach ( $files as $file => $class ) {
			try {
				$path = PSS_PATH . 'elementor/widgets/class-' . $file . '.php';
				if ( ! file_exists( $path ) ) {
					throw new \RuntimeException( 'Missing widget file: ' . $file );
				}
				require_once $path;
				$full = __NAMESPACE__ . '\\Elementor\\Widgets\\' . $class;
				if ( ! class_exists( $full ) ) {
					throw new \RuntimeException( 'Missing widget class: ' . $full );
				}
				$widgets_manager->{$register_method}( new $full() );
				$successful++;
			} catch ( \Throwable $e ) {
				self::$widget_errors[ $file ] = $e->getMessage();
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					error_log( '[PSS] Widget registration failed: ' . $file . ' - ' . $e->getMessage() );
				}
			}
		}

		// Only mark the registry complete when at least one widget was accepted.
		self::$widgets_registered = $successful > 0;
	}

	public static function register_dynamic_tags( $dynamic_tags_manager ) {
		if ( self::$dynamic_tags_registered ) {
			return;
		}
		if ( ! is_object( $dynamic_tags_manager ) || ! method_exists( $dynamic_tags_manager, 'register' ) || ! class_exists( '\Elementor\Core\DynamicTags\Tag' ) ) {
			return;
		}

		try {
			$dir = PSS_PATH . 'elementor/dynamic-tags/class-project-dynamic-tags.php';
			if ( ! file_exists( $dir ) ) {
				return;
			}
			require_once $dir;
			if ( method_exists( $dynamic_tags_manager, 'register_group' ) ) {
				$dynamic_tags_manager->register_group( 'pss-project', array( 'title' => esc_html__( 'Project Showcase', 'project-showcase-studio' ) ) );
			}
			$tags = array(
				'Project_Title', 'Project_Subtitle', 'Project_URL', 'Project_Image', 'Project_Content', 'Project_Meta', 'Project_Field',
			);
			foreach ( $tags as $tag_class ) {
				$full = __NAMESPACE__ . '\\Elementor\\DynamicTags\\' . $tag_class;
				if ( class_exists( $full ) ) {
					$dynamic_tags_manager->register( new $full() );
				}
			}
			self::$dynamic_tags_registered = true;
		} catch ( \Throwable $e ) {
			self::$dynamic_tag_errors[] = $e->getMessage();
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( '[PSS] Dynamic tag registration failed: ' . $e->getMessage() );
			}
		}
	}

	public static function register_styles() { self::register_assets(); }

	public static function register_scripts() { self::register_assets(); }

	public static function preview_url( $url, $document ) {
		if ( ! is_object( $document ) ) {
			return $url;
		}

		$template_id = 0;
		if ( method_exists( $document, 'get_main_id' ) ) {
			$template_id = absint( $document->get_main_id() );
		}
		if ( ! $template_id && method_exists( $document, 'get_id' ) ) {
			$template_id = absint( $document->get_id() );
		}
		if ( ! $template_id || 'elementor_library' !== get_post_type( $template_id ) ) {
			return $url;
		}

		$layout_id = absint( get_post_meta( $template_id, '_pss_manager_layout_id', true ) );
		if ( ! $layout_id || PSS_LAYOUT_CPT !== get_post_type( $layout_id ) ) {
			return $url;
		}
		$preview = absint( get_post_meta( $layout_id, '_pss_preview_project', true ) );
		if ( ! $preview || PSS_PROJECT_CPT !== get_post_type( $preview ) || ! current_user_can( 'edit_post', $layout_id ) ) {
			return $url;
		}

		return add_query_arg(
			array(
				'pss_preview_project' => $preview,
				'pss_preview_layout'  => $layout_id,
			),
			get_permalink( $preview )
		);
	}

	public static function seed_layout_content( $document_id, $style = 'modern' ) {
		$document_id = absint( $document_id );
		if ( ! $document_id ) {
			return;
		}
		$post_type = get_post_type( $document_id );
		if ( PSS_LAYOUT_CPT !== $post_type && 'elementor_library' !== $post_type ) {
			return;
		}
		$elements = $style === 'premium' ? self::premium_elements() : self::modern_elements();
		update_post_meta( $document_id, '_elementor_edit_mode', 'builder' );
		update_post_meta( $document_id, '_elementor_template_type', 'page' );
		update_post_meta( $document_id, '_elementor_data', wp_json_encode( $elements ) );
		update_post_meta( $document_id, '_elementor_page_settings', array() );
		update_post_meta( $document_id, '_elementor_version', defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : PSS_VERSION );
	}

	public static function admin_error_notice() {
		if ( ( empty( self::$widget_errors ) && empty( self::$dynamic_tag_errors ) ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || false === strpos( (string) $screen->id, 'elementor' ) ) {
			return;
		}
		foreach ( self::$widget_errors as $slug => $message ) {
			echo '<div class="notice notice-error"><p><strong>Project Showcase Studio:</strong> Widget <code>' . esc_html( $slug ) . '</code> failed to register. ' . esc_html( $message ) . '</p></div>';
		}
		foreach ( self::$dynamic_tag_errors as $message ) {
			echo '<div class="notice notice-error"><p><strong>Project Showcase Studio:</strong> Dynamic tags failed to register. ' . esc_html( $message ) . '</p></div>';
		}
	}

	private static function el_container( $id, $settings, $elements = array() ) {
		return array( 'id' => $id, 'elType' => 'container', 'settings' => $settings, 'elements' => $elements );
	}

	private static function el_widget( $id, $widget, $settings = array() ) {
		return array( 'id' => $id, 'elType' => 'widget', 'widgetType' => $widget, 'settings' => $settings, 'elements' => array() );
	}

	private static function el_spacer( $id, $height = 22 ) {
		return self::el_widget( $id, 'spacer', array( 'height' => array( 'unit' => 'px', 'size' => $height ) ) );
	}

	private static function modern_elements() {
		$dark = array(
			'content_width' => 'full_width',
			'background_background' => 'classic',
			'background_color' => '#101214',
			'padding' => array( 'unit' => 'px', 'top' => '88', 'right' => '24', 'bottom' => '88', 'left' => '24', 'isLinked' => false ),
		);
		$cream = array(
			'content_width' => 'boxed',
			'background_background' => 'classic',
			'background_color' => '#F3EFE8',
			'padding' => array( 'unit' => 'px', 'top' => '92', 'right' => '24', 'bottom' => '96', 'left' => '24', 'isLinked' => false ),
		);
		return array(
			self::el_container( 'modern-hero', array_merge( $dark, array( 'min_height' => 720, 'justify_content' => 'center', '_css_classes' => 'pss-template-section pss-template-modern-hero' ) ), array(
				self::el_widget( 'modern-breadcrumbs', 'pss_project_breadcrumbs', array() ),
				self::el_spacer( 'modern-hero-gap-1', 30 ),
				self::el_widget( 'modern-hero', 'pss_project_hero', array( 'show_image' => 'yes', 'show_subtitle' => 'yes', 'eyebrow' => 'PROJECT / FEATURED' ) ),
				self::el_spacer( 'modern-hero-gap-2', 30 ),
				self::el_widget( 'modern-hero-button', 'button', array( 'text' => 'Explore the project', 'link' => array( 'url' => '#project-details' ), 'align' => 'left', 'button_text_color' => '#111214', 'background_color' => '#D7C2A1', 'border_radius' => array( 'unit' => 'px', 'size' => 999, 'sizes' => array() ) ) ),
			) ),
			self::el_container( 'modern-intro', array_merge( $cream, array( '_css_classes' => 'pss-template-section pss-template-modern-intro' ) ), array(
				self::el_widget( 'modern-intro-kicker', 'heading', array( 'title' => 'THE IDEA', 'header_size' => 'h6', 'title_color' => '#877D70' ) ),
				self::el_widget( 'modern-intro-title', 'heading', array( 'title' => 'A project told through space, material and detail.', 'header_size' => 'h2', 'title_color' => '#17191D' ) ),
				self::el_widget( 'modern-intro-copy', 'pss_project_description', array() ),
				self::el_widget( 'modern-intro-meta', 'pss_project_meta', array( 'layout' => 'grid' ) ),
			) ),
			self::el_container( 'modern-stats', array_merge( $dark, array( 'background_color' => '#161A1E', '_css_classes' => 'pss-template-section pss-template-modern-stats' ) ), array(
				self::el_widget( 'modern-stats-kicker', 'heading', array( 'title' => 'AT A GLANCE', 'header_size' => 'h6', 'title_color' => '#AAB0B7' ) ),
				self::el_spacer( 'modern-stats-gap', 16 ),
				self::el_widget( 'modern-stats-widget', 'pss_project_stats', array() ),
			) ),
			self::el_container( 'modern-gallery', array_merge( $dark, array( '_css_classes' => 'pss-template-section pss-template-gallery-wall' ) ), array(
				self::el_widget( 'modern-gallery-title', 'heading', array( 'title' => 'SELECTED IMAGES', 'header_size' => 'h2', 'title_color' => '#FFFFFF' ) ),
				self::el_widget( 'modern-gallery-copy', 'text-editor', array( 'editor' => '<p>Material, light, proportion and craft — presented as a visual sequence.</p>', 'text_color' => '#AAB0B7' ) ),
				self::el_spacer( 'modern-gallery-gap', 16 ),
				self::el_widget( 'modern-gallery-widget', 'pss_project_gallery', array( 'layout' => 'masonry' ) ),
			) ),
			self::el_container( 'modern-details', array_merge( $cream, array( '_css_classes' => 'pss-template-section pss-template-modern-details', 'id' => 'project-details' ) ), array(
				self::el_widget( 'modern-details-kicker', 'heading', array( 'title' => 'PROJECT DNA', 'header_size' => 'h6', 'title_color' => '#877D70' ) ),
				self::el_widget( 'modern-details-title', 'heading', array( 'title' => 'Specifications, fields and the choices that make this project unique.', 'header_size' => 'h2', 'title_color' => '#17191D' ) ),
				self::el_spacer( 'modern-details-gap', 22 ),
				self::el_widget( 'modern-specs', 'pss_project_specifications', array() ),
				self::el_spacer( 'modern-details-gap-2', 22 ),
				self::el_widget( 'modern-fields', 'pss_project_custom_fields', array() ),
				self::el_spacer( 'modern-details-gap-3', 22 ),
				self::el_widget( 'modern-features', 'pss_project_features', array() ),
			) ),
			self::el_container( 'modern-materials', array( 'content_width' => 'boxed', 'background_background' => 'classic', 'background_color' => '#D9C8AF', 'padding' => array( 'unit' => 'px', 'top' => '86', 'right' => '24', 'bottom' => '94', 'left' => '24', 'isLinked' => false ), '_css_classes' => 'pss-template-section pss-template-three-column' ), array(
				self::el_widget( 'modern-materials', 'pss_project_materials', array() ),
				self::el_widget( 'modern-services', 'pss_project_services', array() ),
				self::el_widget( 'modern-location', 'pss_project_location', array() ),
			) ),
			self::el_container( 'modern-transformation', array_merge( $dark, array( 'background_color' => '#0C0E10', '_css_classes' => 'pss-template-section pss-template-media-split' ) ), array(
				self::el_widget( 'modern-transformation-title', 'heading', array( 'title' => 'TRANSFORMATION', 'header_size' => 'h2', 'title_color' => '#FFFFFF' ) ),
				self::el_widget( 'modern-before-after', 'pss_project_before_after', array( 'height' => 560 ) ),
				self::el_widget( 'modern-video', 'pss_project_video', array( 'ratio' => '16-9' ) ),
			) ),
			self::el_container( 'modern-products', array_merge( $cream, array( 'background_color' => '#ECE6DD', '_css_classes' => 'pss-template-section pss-template-products' ) ), array(
				self::el_widget( 'modern-products-kicker', 'heading', array( 'title' => 'OBJECTS / MATERIALS / PRODUCTS', 'header_size' => 'h6', 'title_color' => '#877D70' ) ),
				self::el_widget( 'modern-products-title', 'heading', array( 'title' => 'Designed spaces can become shoppable stories.', 'header_size' => 'h2', 'title_color' => '#17191D' ) ),
				self::el_spacer( 'modern-products-gap', 18 ),
				self::el_widget( 'modern-products-grid', 'pss_project_products', array( 'layout' => 'grid' ) ),
			) ),
			self::el_container( 'modern-cta', array_merge( $dark, array( 'background_color' => '#17191D', '_css_classes' => 'pss-template-section pss-template-cta' ) ), array(
				self::el_widget( 'modern-cta-title', 'heading', array( 'title' => 'Need a project with this level of detail?', 'header_size' => 'h2', 'title_color' => '#FFFFFF' ) ),
				self::el_widget( 'modern-cta-copy', 'text-editor', array( 'editor' => '<p>Use this section as your enquiry, contact or project hand-off area.</p>', 'text_color' => '#B8BDC4' ) ),
				self::el_widget( 'modern-cta-widget', 'pss_project_inquiry', array() ),
			) ),
			self::el_container( 'modern-related', array( 'content_width' => 'boxed', 'background_background' => 'classic', 'background_color' => '#FFFFFF', 'padding' => array( 'unit' => 'px', 'top' => '92', 'right' => '24', 'bottom' => '96', 'left' => '24', 'isLinked' => false ), '_css_classes' => 'pss-template-section pss-template-related' ), array(
				self::el_widget( 'modern-related-title', 'heading', array( 'title' => 'MORE PROJECTS', 'header_size' => 'h6', 'title_color' => '#877D70' ) ),
				self::el_widget( 'modern-related-headline', 'heading', array( 'title' => 'Continue exploring.', 'header_size' => 'h2', 'title_color' => '#17191D' ) ),
				self::el_widget( 'modern-related-grid', 'pss_related_projects', array( 'limit' => 3, 'layout' => 'cards' ) ),
				self::el_spacer( 'modern-related-gap', 28 ),
				self::el_widget( 'modern-navigation', 'pss_project_navigation', array() ),
			) ),
		);
	}

	private static function premium_elements() {
		$dark = array( 'content_width' => 'full_width', 'background_background' => 'classic', 'background_color' => '#11100E', 'padding' => array( 'unit' => 'px', 'top' => '92', 'right' => '24', 'bottom' => '92', 'left' => '24', 'isLinked' => false ) );
		$ivory = array( 'content_width' => 'boxed', 'background_background' => 'classic', 'background_color' => '#F5F0E7', 'padding' => array( 'unit' => 'px', 'top' => '92', 'right' => '24', 'bottom' => '100', 'left' => '24', 'isLinked' => false ) );
		return array(
			self::el_container( 'premium-hero', array_merge( $dark, array( 'min_height' => 780, 'justify_content' => 'center', '_css_classes' => 'pss-template-section pss-template-premium-hero' ) ), array(
				self::el_widget( 'premium-breadcrumbs', 'pss_project_breadcrumbs', array() ), self::el_spacer( 'premium-gap-1', 34 ), self::el_widget( 'premium-hero-widget', 'pss_project_hero', array( 'show_image' => 'yes', 'show_subtitle' => 'yes', 'eyebrow' => 'PRIVATE RESIDENCE / SIGNATURE PROJECT' ) ), self::el_spacer( 'premium-gap-2', 28 ), self::el_widget( 'premium-hero-cta', 'button', array( 'text' => 'Enter the project', 'link' => array( 'url' => '#premium-story' ), 'align' => 'left', 'button_text_color' => '#11100E', 'background_color' => '#D6C29D', 'border_radius' => array( 'unit' => 'px', 'size' => 999, 'sizes' => array() ) ) ),
			) ),
			self::el_container( 'premium-meta', array( 'content_width' => 'boxed', 'background_background' => 'classic', 'background_color' => '#CDB995', 'padding' => array( 'unit' => 'px', 'top' => '28', 'right' => '24', 'bottom' => '28', 'left' => '24', 'isLinked' => false ), '_css_classes' => 'pss-template-premium-bar' ), array(
				self::el_widget( 'premium-meta-widget', 'pss_project_meta', array( 'layout' => 'inline' ) ),
			) ),
			self::el_container( 'premium-story', array_merge( $dark, array( 'background_color' => '#171513', '_css_classes' => 'pss-template-section pss-template-premium-story', 'id' => 'premium-story' ) ), array(
				self::el_widget( 'premium-story-eyebrow', 'heading', array( 'title' => 'A QUIET, MATERIAL-LED APPROACH', 'header_size' => 'h6', 'title_color' => '#CDB995' ) ),
				self::el_widget( 'premium-story-title', 'heading', array( 'title' => 'Crafted details. Calm proportions. A space designed to last.', 'header_size' => 'h2', 'title_color' => '#F6F0E6' ) ),
				self::el_widget( 'premium-story-description', 'pss_project_description', array() ),
				self::el_widget( 'premium-story-stats', 'pss_project_stats', array() ),
			) ),
			self::el_container( 'premium-editorial', array_merge( $ivory, array( '_css_classes' => 'pss-template-section pss-template-premium-columns' ) ), array(
				self::el_widget( 'premium-editorial-title', 'heading', array( 'title' => 'The brief, the material and the finished result.', 'header_size' => 'h2', 'title_color' => '#191714' ) ),
				self::el_widget( 'premium-editorial-specs', 'pss_project_specifications', array() ),
				self::el_widget( 'premium-editorial-fields', 'pss_project_custom_fields', array() ),
			) ),
			self::el_container( 'premium-gallery', array_merge( $dark, array( 'background_color' => '#0D0E10', '_css_classes' => 'pss-template-section pss-template-premium-gallery' ) ), array(
				self::el_widget( 'premium-gallery-kicker', 'heading', array( 'title' => 'THE VISUAL SEQUENCE', 'header_size' => 'h6', 'title_color' => '#CDB995' ) ),
				self::el_widget( 'premium-gallery-title', 'heading', array( 'title' => 'A cinematic walk through the space.', 'header_size' => 'h2', 'title_color' => '#FFFFFF' ) ),
				self::el_spacer( 'premium-gallery-gap', 24 ), self::el_widget( 'premium-gallery-widget', 'pss_project_gallery', array( 'layout' => 'masonry' ) ),
			) ),
			self::el_container( 'premium-materials', array_merge( $ivory, array( 'background_color' => '#EAE1D3', '_css_classes' => 'pss-template-section pss-template-premium-columns' ) ), array(
				self::el_widget( 'premium-materials-title', 'heading', array( 'title' => 'Materials / Services / Location', 'header_size' => 'h2', 'title_color' => '#191714' ) ),
				self::el_widget( 'premium-materials-widget', 'pss_project_materials', array() ), self::el_widget( 'premium-services-widget', 'pss_project_services', array() ), self::el_widget( 'premium-location-widget', 'pss_project_location', array() ),
			) ),
			self::el_container( 'premium-transformation', array_merge( $dark, array( 'background_color' => '#171513', '_css_classes' => 'pss-template-section pss-template-premium-media' ) ), array(
				self::el_widget( 'premium-transformation-title', 'heading', array( 'title' => 'TRANSFORMATION', 'header_size' => 'h2', 'title_color' => '#F6F0E6' ) ),
				self::el_widget( 'premium-transformation-ba', 'pss_project_before_after', array( 'height' => 600 ) ), self::el_widget( 'premium-transformation-video', 'pss_project_video', array( 'ratio' => '16-9' ) ),
			) ),
			self::el_container( 'premium-products', array_merge( $ivory, array( 'background_color' => '#F8F2E9', '_css_classes' => 'pss-template-section pss-template-products' ) ), array(
				self::el_widget( 'premium-products-kicker', 'heading', array( 'title' => 'COLLECTED OBJECTS', 'header_size' => 'h6', 'title_color' => '#8B7B60' ) ),
				self::el_widget( 'premium-products-title', 'heading', array( 'title' => 'Pieces that complete the story.', 'header_size' => 'h2', 'title_color' => '#191714' ) ),
				self::el_spacer( 'premium-products-gap', 18 ), self::el_widget( 'premium-products-widget', 'pss_project_products', array( 'layout' => 'carousel' ) ),
			) ),
			self::el_container( 'premium-cta', array_merge( $dark, array( 'background_color' => '#0C0D0E', '_css_classes' => 'pss-template-section pss-template-premium-cta' ) ), array(
				self::el_widget( 'premium-cta-title', 'heading', array( 'title' => 'Ready for your own signature project?', 'header_size' => 'h2', 'title_color' => '#FFFFFF' ) ),
				self::el_widget( 'premium-cta-copy', 'text-editor', array( 'editor' => '<p>Turn this final section into your enquiry, booking or consultation call-to-action.</p>', 'text_color' => '#B9B0A3' ) ),
				self::el_widget( 'premium-cta-widget', 'pss_project_inquiry', array() ),
			) ),
			self::el_container( 'premium-related', array_merge( $dark, array( 'background_color' => '#171513', '_css_classes' => 'pss-template-section pss-template-related' ) ), array(
				self::el_widget( 'premium-related-kicker', 'heading', array( 'title' => 'SELECTED WORK', 'header_size' => 'h6', 'title_color' => '#CDB995' ) ),
				self::el_widget( 'premium-related-title', 'heading', array( 'title' => 'More spaces worth exploring.', 'header_size' => 'h2', 'title_color' => '#F6F0E6' ) ),
				self::el_widget( 'premium-related-grid', 'pss_related_projects', array( 'limit' => 3, 'layout' => 'cards' ) ), self::el_spacer( 'premium-related-gap', 28 ), self::el_widget( 'premium-related-nav', 'pss_project_navigation', array() ),
			) ),
		);
	}

}
